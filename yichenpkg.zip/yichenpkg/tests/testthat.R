library(testthat)
library(yichenpkg)

test_check("yichenpkg")
