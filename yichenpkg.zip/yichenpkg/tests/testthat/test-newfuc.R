test_that("multiplication works", {
  expect_equal(2 * 2, 4)
})

test_that("function returns numeric value", {
  expect_type(log_summed_exps((seq(1:2000))), "double")
})

test_that("function returns numeric value", {
  expect_true(log_summed_exps((seq(1:2000))) != Inf)
})
